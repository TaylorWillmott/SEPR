<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="rpg-tiles-64" tilewidth="64" tileheight="64" tilecount="260" columns="20">
 <image source="rpg-tiles-64.png" width="1280" height="832"/>
</tileset>
