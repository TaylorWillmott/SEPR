package other;

/**
 * The different screens that can be switched to within the game
 */
public enum Screen {
    MENU
}
